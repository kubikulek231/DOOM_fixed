#ifndef YKEY_H
#define YKEY_H

#include <X11/XKBlib.h>
#include <X11/keysym.h>

#endif

// vim: set sw=4 ts=4 et:
