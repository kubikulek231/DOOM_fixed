$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: no se encontraron pantallas manejables, abortando\n
$ #MapRequest
# Blackbox::process_event: MapRequest para 0x%lx\n
