$set 15 #Common

$ #Yes
# S�
$ #No
# No

$ #DirectionTitle
# Direcci�n
$ #DirectionHoriz
# Horizontal
$ #DirectionVert
# Vertical

$ #AlwaysOnTop
# Siempre Encima

$ #PlacementTitle
# Ubicaci�n
$ #PlacementTopLeft
# Arriba, Izquierda
$ #PlacementCenterLeft
# Centro, Izquierda
$ #PlacementBottomLeft
# Abajo, Izquierda
$ #PlacementTopCenter
# Arriba, Centro
$ #PlacementBottomCenter
# Abajo, Centro
$ #PlacementTopRight
# Arriba, Derecha
$ #PlacementCenterRight
# Centro, Derecha
$ #PlacementBottomRight
# Abajo, Derecha

$ #AutoHide
# Ocultar Autom�ticamente
