$set 3 #Configmenu

$ #ConfigOptions
# Opciones de Configuraci�n
$ #FocusModel
# Modelo del Foco
$ #WindowPlacement
# Ubicaci�n de las Ventanas
$ #ImageDithering
# Simulaci�n Ordenada de Colores en Im�genes
$ #OpaqueMove
# Movimiento Opaco de Ventanas
$ #FullMax
# Maximizaci�n Total
$ #FocusNew
# Enfocar Nuevas Ventanas
$ #FocusLast
# Enfocar la Ultima Ventana en el Escritorio
$ #DisableBindings
# Deshabilitar Enlaces con Bloq Despl
$ #ClickToFocus
# Click Para Enfocar
$ #SloppyFocus
# Foco Sigue Al Rat�n
$ #AutoRaise
# Elevar Autom�ticamente
$ #ClickRaise
# Click Para Elevar
$ #SmartRows
# Ubicaci�n Inteligente (Filas)
$ #SmartCols
# Ubicaci�n Inteligente (Columnas)
$ #Cascade
# Ubicaci�n en Cascada
$ #LeftRight
# Izquierda A Derecha
$ #RightLeft
# Derecha A Izquierda
$ #TopBottom
# De Arriba Abajo
$ #BottomTop
# De Abajo Arriba
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
