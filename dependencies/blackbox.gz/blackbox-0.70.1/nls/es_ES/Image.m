$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: error creando pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: error creando XImage\n
$ #UnsupVisual
# BImage::renderXImage: visual no soportada\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: error creando pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: tama�o del mapa de colores inv�lido %d (%d/%d/%d) - reduciendo\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: error asignando el mapa de colores\n
$ #ColorAllocFail
# BImageControl::BImageControl: error al asignar el mapa de colores %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: reserva de pixmaps - liberando %d pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: reserva de pixmaps demasiado grande, forzando limpieza\n
$ #ColorParseError
# BImageControl::getColor: error evaluando el color: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: error asignando el color: '%s'\n
