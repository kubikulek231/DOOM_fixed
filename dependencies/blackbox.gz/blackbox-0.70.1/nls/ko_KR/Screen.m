$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: an error occured while querying the X server.\n  \
another window manager is already running on display %s.\n
$ #ManagingScreen
# BScreen::BScreen: managing screen %d using visual 0x%lx, depth %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): couldn't load font '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): couldn't load default font.\n
$ #EmptyMenuFile
# %s: empty menu file\n
$ #xterm
# ������
$ #Restart
# �����
$ #Exit
# ����
$ #EXECError
# BScreen::parseMenuFile: [exec] error, no menu label and/or command defined\n
$ #EXITError
# BScreen::parseMenuFile: [exit] error, no menu label defined\n
$ #STYLEError
# BScreen::parseMenuFile: [style] error, no menu label and/or filename \
defined\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] error, no menu label defined\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] error, no filename defined\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] error, '%s' is not a regular file\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] error, no menu label defined\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] error, no menu label defined\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] error, no menu label defined\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] error, no directory defined\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] error, '%s' is not a \
directory\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] error, '%s' does not exist\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] error, no menu label defined\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

