$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: Fehler bei der Erstellung der Pixmap\n
$ #ErrorCreatingXImage
# BImage::renderXImage: Fehler bei der Erstellung des XImage\n
$ #UnsupVisual
# BImage::renderXImage: nicht unterst�tztes Visual\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: Fehler bei der Erstellung der Pixmap\n
$ #InvalidColormapSize
# BImageControl::BImageControl: Ung�ltige Colormap Gr��e %d (%d/%d/%d) - verkleinere\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: Fehler bei der Anlegung der Colormap\n
$ #ColorAllocFail
# BImageControl::BImageControl: Fehler bei der Auswertung der Farbe %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: Pixmap Cache - Freigabe von %d Pixmaps\n
$ #PixmapCacheLarge
# BImageControl::renderImage: Cache zu gro�, Ausleerung erfordert\n
$ #ColorParseError
# BImageControl::getColor: Color Parse Fehler: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: Color Alloc Fehler: '%s'\n
