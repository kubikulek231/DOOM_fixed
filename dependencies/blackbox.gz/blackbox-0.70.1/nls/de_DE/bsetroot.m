$set 16 #bsetroot

$ #MustSpecify
# %s: error: must specify one of: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        Display Verbindung\n\
  -mod <x> <y>             Modula Muster\n\
  -foreground, -fg <color> Modula Vordergrund Farbe\n\
  -background, -bg <color> Modula Hintergrund Farbe\n\n\
  -gradient <texture>      steigernde Beschaffenheit\n\
  -from <color>            Anfangsfarbe\n\
  -to <color>              Endfarbe\n\n\
  -solid <color>           volle Farbe\n\n\
  -help                    Anzeige dieser Hilfe und Beendung\n

