$set 3 #Configmenu

$ #ConfigOptions
# Einstellungen
$ #FocusModel
# Fokus Model
$ #WindowPlacement
# Fenster Plazierung
$ #ImageDithering
# Image Dithering
$ #OpaqueMove
# Fenster beim Verschieben durchsichtig
$ #FullMax
# Vollst�ndige Vergr��erung
$ #FocusNew
# Fokus auf Neue Fenster
$ #FocusLast
# Fokus auf letztes Fenster bei Arbeitsplatz Wechsel
$ #DisableBindings
# Scroll Lock verhindert Bindings
$ #ClickToFocus
# Fokus durch Mausklick
$ #SloppyFocus
# Fokus folgt Maus
$ #AutoRaise
# Automatische Erhebung
$ #ClickRaise
# Klick Erhebung
$ #SmartRows
# Optimale Plazierung (Reihen)
$ #SmartCols
# Optimale Plazierung (Spalten)
$ #Cascade
# Verschobene Plazierung
$ #LeftRight
# Von links nach rechts
$ #RightLeft
# Von rechts nach links
$ #TopBottom
# Von oben nach unten
$ #BottomTop
# Von unten nach oben
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
