$set 15 #Common

$ #Yes
# Ja
$ #No
# Nein

$ #DirectionTitle
# Ausrichtung
$ #DirectionHoriz
# Horizontal
$ #DirectionVert
# Vertikal

$ #AlwaysOnTop
# Immer im Vorgrund

$ #PlacementTitle
# Platzierung
$ #PlacementTopLeft
# Oben Links
$ #PlacementCenterLeft
# Mitte Links
$ #PlacementBottomLeft
# Unten Links
$ #PlacementTopCenter
# Oben Mitte
$ #PlacementBottomCenter
# Unten Mitte
$ #PlacementTopRight
# Oben Rechts
$ #PlacementCenterRight
# Mitte Rechts
$ #PlacementBottomRight
# Unten Rechts

$ #AutoHide
# Automatisch Verbergen
