$set 1 #BaseDisplay

$ #XError
# %s:  X error: %s(%d) opcodes %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: signal %d caught\n
$ #ShuttingDown
# shutting down\n
$ #Aborting
# aborting... dumping core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: connection to X server failed.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: couldn't mark display connection as close-on-exec\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): removing bad window from event queue\n
