$set 15 #Common

$ #Yes
# Ja
$ #No
# Nej

$ #DirectionTitle
# Retning
$ #DirectionHoriz
# Horisontal
$ #DirectionVert
# Vertikal

$ #AlwaysOnTop
# Altid �verst

$ #PlacementTitle
# Placering
$ #PlacementTopLeft
# �verste venstre hj�rne
$ #PlacementCenterLeft
# Venstre i midten
$ #PlacementBottomLeft
# Bunden til venstre
$ #PlacementTopCenter
# Toppen i midten
$ #PlacementBottomCenter
# Bunden i midten
$ #PlacementTopRight
# �verst til h�jre
$ #PlacementCenterRight
# Til h�jre i midten
$ #PlacementBottomRight
# Til h�jre i bunden

$ #AutoHide
# Gem automatisk
