$set 10 #Windowmenu

$ #SendTo
# Send til ...
$ #Shade
# Skygge
$ #Iconify
# Iconificeret
$ #Maximize
# Maksimer
$ #Raise
# H�v
$ #Lower
# S�nk
$ #Stick
# Kl�brig
$ #KillClient
# Dr�b klient
$ #Close
# Luk
