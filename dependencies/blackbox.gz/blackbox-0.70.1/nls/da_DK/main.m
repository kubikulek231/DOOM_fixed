$set 14 #main

$ #RCRequiresArg
# fejl: '-rc' kr�ver et argument\n
$ #DISPLAYRequiresArg
# fjel: '-display' kr�ver et argument\n
$ #WarnDisplaySet
# advarsel: kunne ikke s�tte variablen 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tbrug sk�rm tilslutning.\n\
  -rc <string>\t\t\tbrug alternativ resource fil.\n\
  -version\t\t\tvis versionsnummer og afslut.\n\
  -help\t\t\t\tvis denne hj�lp og afslut.\n\n
$ #CompileOptions
# Kompileret med:\n\
  Debugging\t\t\t%s\n\
  Shape:\t\t\t%s\n\
  8bpp Ordered Dithering:\t%s\n\n
