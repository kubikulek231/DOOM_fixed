$set 15 #Common

$ #Yes
# Ja
$ #No
# Nee

$ #DirectionTitle
# Richting
$ #DirectionHoriz
# Horizontaal
$ #DirectionVert
# Vertikaal

$ #AlwaysOnTop
# Altijd op voorgrond

$ #PlacementTitle
# Plaatsing
$ #PlacementTopLeft
# Linksboven
$ #PlacementCenterLeft
# Links
$ #PlacementBottomLeft
# Linksonder
$ #PlacementTopCenter
# Middenboven
$ #PlacementBottomCenter
# Middenonder
$ #PlacementTopRight
# Rechtsboven
$ #PlacementCenterRight
# Rechts
$ #PlacementBottomRight
# Rechtsonder

$ #AutoHide
# Automatisch verbergen
