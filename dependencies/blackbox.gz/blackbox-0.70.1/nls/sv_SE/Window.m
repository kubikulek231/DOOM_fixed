$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: skapar 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributes misslyckades\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: kan inte hitta sk�rm f�r rootf�nster 0x%lx\n
$ #Unnamed
# Inget namn
$ #MapRequest
# BlackboxWindow::mapRequestEvent() f�r 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() f�r 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: �terf�r 0x%lx till 0x%lx\n
