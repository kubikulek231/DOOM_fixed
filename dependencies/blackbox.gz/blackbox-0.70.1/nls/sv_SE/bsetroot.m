$set 16 #bsetroot

$ #MustSpecify
# %s: fel: m�ste specifiera en av: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        sk�rmanslutning\n\
  -mod <x> <y>             modulam�nster\n\
  -foreground, -fg <color> f�rgrundsf�rg f�r modulam�nster\n\
  -background, -bg <color> bakgrundsf�rg f�r modulam�nster\n\n\
  -gradient <texture>      texturlutning\n\
  -from <color>            startf�rg\n\
  -to <color>              slutf�rg\n\n\
  -solid <color>           solid f�rg\n\n\
  -help                    visa denna hj�lptext och avsluta\n

