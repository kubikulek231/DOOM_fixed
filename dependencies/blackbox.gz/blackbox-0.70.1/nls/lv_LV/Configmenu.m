$set 3 #Configmenu

$ #ConfigOptions
# Konfigur�cijas Opcijas
$ #FocusModel
# Fokus��an�s Modelis
$ #WindowPlacement
# Loga Novietojums
$ #ImageDithering
# Att�la Ton��ana
$ #OpaqueMove
# Necaurredzama Loga P�rvieto�ana
$ #FullMax
# Pilna Maksimiz�cija
$ #FocusNew
# Fokus�t Jaunos Logus
$ #DisableBindings
# Deaktiviz�t Sasaistes ar Ritsl�ga tausti�u
$ #FocusLast
# Fokus�t Logu pie Darba vietas mai�as
$ #ClickToFocus
# Klik��is, lai Fokus�tu
$ #SloppyFocus
# Nev���ga Fokus��ana
$ #AutoRaise
# Auto Pacel�ana
$ #ClickRaise
# Klik��is Pace�
$ #SmartRows
# Gudr� Novieto�ana (Rind�s)
$ #SmartCols
# Gudr� Novieto�ana (Kolonn�s)
$ #Cascade
# Kask�des Novieto�ana
$ #LeftRight
# No Kreis�s un Labo
$ #RightLeft
# No Lab�s uz Kreiso
$ #TopBottom
# No Aug�as uz Leju
$ #BottomTop
# No Lejas uz Aug�u
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
