$set 15 #Common

$ #Yes
# J�
$ #No
# N�

$ #DirectionTitle
# Virziens
$ #DirectionHoriz
# Horizont�ls
$ #DirectionVert
# Vertik�ls

$ #AlwaysOnTop
# Vienm�r virspus�

$ #PlacementTitle
# Novieto�ana
$ #PlacementTopLeft
# Aug�� pa Kreisi
$ #PlacementCenterLeft
# Centr� pa Kreisi
$ #PlacementBottomLeft
# Apak�� pa Kreisi
$ #PlacementTopCenter
# Aug�� Centr�
$ #PlacementBottomCenter
# Apak�� Centr�
$ #PlacementTopRight
# Aug�� pa Labi
$ #PlacementCenterRight
# Centr� pa Labi
$ #PlacementBottomRight
# Apak�� pa Labi
$ #AutoHide
# Auto pasl�pt
