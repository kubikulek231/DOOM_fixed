$set 10 #Windowmenu

$ #SendTo
# S�t�t Uz ...
$ #Shade
# �not
$ #Iconify
# Ikonific�t
$ #Maximize
# Maksimiz�t
$ #Raise
# Pacelt
$ #Lower
# Pazemin�t
$ #Stick
# Sti��t
$ #KillClient
# Nokaut Klientu
$ #Close
# Aizv�rt
