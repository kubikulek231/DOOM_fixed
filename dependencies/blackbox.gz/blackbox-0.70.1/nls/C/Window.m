$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: creating 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres failed\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: cannot find screen for root window 0x%lx\n
$ #Unnamed
# Unnamed
$ #MapRequest
# BlackboxWindow::mapRequestEvent() for 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() for 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reparent 0x%lx to 0x%lx\n
