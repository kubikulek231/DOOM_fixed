$set 15 #Common

$ #Yes
# Yes
$ #No
# No

$ #DirectionTitle
# Direction
$ #DirectionHoriz
# Horizontal
$ #DirectionVert
# Vertical

$ #AlwaysOnTop
# Always on top

$ #PlacementTitle
# Placement
$ #PlacementTopLeft
# Top Left
$ #PlacementCenterLeft
# Center Left
$ #PlacementBottomLeft
# Bottom Left
$ #PlacementTopCenter
# Top Center
$ #PlacementBottomCenter
# BottomCenter
$ #PlacementTopRight
# Top Right
$ #PlacementCenterRight
# Center Right
$ #PlacementBottomRight
# Bottom Right

$ #AutoHide
# Auto hide
