$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: feil ved opprettelse av pikselkart\n
$ #ErrorCreatingXImage
# BImage::renderXImage: feil ved opprettelse av XImage\n
$ #UnsupVisual
# BImage::renderXImage: fargedybden er ikke st�ttet\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: feil ved opprettelse av pikselkart\n
$ #InvalidColormapSize
# BImageControl::BImageControl: ugyldig st�rrelse p� fargekart %d (%d/%d/%d) - reduserer\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: feil ved allokering av fargekart\n
$ #ColorAllocFail
# BImageControl::BImageControl: feil ved allokering av farge %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pikselkart-hurtigminne - sletter %d pikselkart\n
$ #PixmapCacheLarge
# BImageControl::renderImage: hurtigminnet er stort, tvinger opprydding\n
$ #ColorParseError
# BImageControl::getColor: Feil ved lesning av farge: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: Fargeallokerings-feil: '%s'\n
