$set 10 #Windowmenu

$ #SendTo
# Send til ...
$ #Shade
# Skygg
$ #Iconify
# Minimer til ikon
$ #Maximize
# Maksimer
$ #Raise
# Hev
$ #Lower
# Senk
$ #Stick
# Klebrig
$ #KillClient
# Terminer klient
$ #Close
# Lukk
