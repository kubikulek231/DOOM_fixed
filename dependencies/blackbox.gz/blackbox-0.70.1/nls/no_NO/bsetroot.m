$set 16 #bsetroot

$ #MustSpecify
# %s: feil: �n av f�lgende opsjoner m� spesifiseres: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        skjermtilkobling3\n\
  -mod <x> <y>             modula m�nster\n\
  -foreground, -fg <color> modula forgrunnsfarge\n\
  -background, -bg <color> modula bakgrunnsfarge\n\n\
  -gradient <texture>      gradient tekstur\n\
  -from <color>            gradient start farge\n\
  -to <color>              gradient slutt farge\n\n\
  -solid <color>           ensfarget\n\n\
  -help                    vis denne hjelpeteksten og avslutt\n
