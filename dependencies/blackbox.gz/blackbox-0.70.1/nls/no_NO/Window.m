$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: oppretter 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres feilet\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: finner ikke skjerm til rotvindu 0x%lx\n
$ #Unnamed
# Ikke navngitt
$ #MapRequest
# BlackboxWindow::mapRequestEvent() for 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() for 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: setter 0x%lx til 0x%lx\n
