$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: ingen h�ndterbare skjermer funnet, avbryter\n
$ #MapRequest
# Blackbox::process_event: MapRequest for 0x%lx\n
