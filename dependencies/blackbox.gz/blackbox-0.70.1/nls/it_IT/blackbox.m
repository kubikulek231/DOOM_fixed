$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: nessuno schermo gestibile trovatono, annullamento\n
$ #MapRequest
# Blackbox::process_event: MapRequest per 0x%lx\n
