$set 12 #Workspacemenu

$ #WorkspacesTitle
# Aree di Lavoro
$ #NewWorkspace
# Nuova Area di Lavoro
$ #RemoveLast
# Rimuovi Ultima
