$set 3 #Configmenu

$ #ConfigOptions
# Be�ll�t�sok
$ #FocusModel
# F�kusz modell
$ #WindowPlacement
# Ablakok elhelyez�se
$ #ImageDithering
# Image dithering
$ #OpaqueMove
# �tl�tsz� ablakok mozgat�s k�zben
$ #FullMax
# Teljesk�perny�s maximaliz�l�s
$ #FocusNew
# �j ablak kapja a f�kuszt
$ #FocusLast
# Munkaasztal v�lt�sa ut�n f�kusz az utols� ablakon
$ #DisableBindings
# Scroll Lock-n�l nem figyeli a billenty�zetet
$ #ClickToFocus
# Kattint�s f�kuszhoz
$ #SloppyFocus
# A f�kusz k�veti az egeret
$ #AutoRaise
# Aut�matikus el�reugr� ablakok
$ #ClickRaise
# Kattint�ssal az el�t�rbe
$ #SmartRows
# Optim�lis ablakrendez�s (sorok)
$ #SmartCols
# Optim�lis ablakrendez�s (oszlopok)
$ #Cascade
# Egym�sracs�sztatott elrendez�s
$ #LeftRight
# Jobbr�l balra
$ #RightLeft
# Balr�l jobbra
$ #TopBottom
# Fentr�l lefele
$ #BottomTop
# Lentr�l felfele
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
