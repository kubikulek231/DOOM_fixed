$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: 0x%lx l�trehoz�sa\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: sikertelen XGetWindowAttributres\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: nem tal�lhat� k�perny� root window 0x%lx-nak\n
$ #Unnamed
# N�vtelen
$ #MapRequest
# BlackboxWindow::mapRequestEvent() for 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() for  0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reparent 0x%lx to 0x%lx\n
