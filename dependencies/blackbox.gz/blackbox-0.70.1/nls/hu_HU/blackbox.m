$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: nem tal�lhat� kezelhet� k�perny�, befejez�s\n
$ #MapRequest
# Blackbox::process_event: MapRequest for 0x%lx\n
