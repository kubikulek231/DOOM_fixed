$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: hiba az X szerver k�rdez�s�n�l.\n \
Egy m�sik ablakkezel� m�r haszn�lja a %s k�perny�t.\n
$ #ManagingScreen
# BScreen::BScreen: �tvette az ir�ny�t�st a %d k�perny�n. visual: 0x%lx, sz�nm�lys�g: %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): nem lehet a '%s' bet�t�pust bet�lteni\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): az alap�rtelmezett bet�t�pus bet�lt�se nem lehets�ges.\n
$ #EmptyMenuFile
# %s: �res men� file\n
$ #xterm
# termin�l
$ #Restart
# �jraind�t�s
$ #Exit
# Kil�p�s
$ #EXECError
# BScreen::parseMenuFile: [exec] Hiba, nincs men� c�mke �s/vagy parancs meghat�rozva\n
$ #EXITError
# BScreen::parseMenuFile: [exit] Hiba, nincs men� c�mke meghat�rozva\n
$ #STYLEError
# BScreen::parseMenuFile: [style] Hiba, nincs men� c�mke �s/vagy file-n�v meghat�rozva\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] Hiba, nincs men� c�mke meghat�rozva\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] Hiba, nincs file-n�v meghat�rozva\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] Hiba, '%s' nem egy szab�lyos file\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] Hiba, nincs men� c�mke meghat�rozva\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] Hiba, nincs men� c�mke meghat�rozva\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] Hiba, nincs men� c�mke meghat�rozva\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Hiba, nincs meghat�rozva k�nyvt�r\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Hiba, '%s' nem k�nyvt�r\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] Hiba, '%s' nem l�tezik\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] Hiba, nincs men� c�mke meghat�rozva\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

