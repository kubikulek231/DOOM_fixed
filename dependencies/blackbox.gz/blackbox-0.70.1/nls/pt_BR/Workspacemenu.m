$set 12 #Workspacemenu

$ #WorkspacesTitle
# Areas de Trabalho
$ #NewWorkspace
# Nova Area de Trabalho
$ #RemoveLast
# Remover Ultima
