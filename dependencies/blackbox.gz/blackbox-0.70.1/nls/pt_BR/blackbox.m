$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: n�o encontradas telas gerenciaveis, abortando..\n
$ #MapRequest
# Blackbox::process_event: MapRequest para 0x%lx\n
