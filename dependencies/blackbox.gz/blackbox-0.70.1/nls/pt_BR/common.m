$set 15 #Common

$ #Yes
# Sim
$ #No
# N�o

$ #DirectionTitle
# Dire��o
$ #DirectionHoriz
# Horizontal
$ #DirectionVert
# Vertical

$ #AlwaysOnTop
# Sempre v�sivel

$ #PlacementTitle
# Posicionamento
$ #PlacementTopLeft
# No Alto a Esquerda
$ #PlacementCenterLeft
# No Centro a Esquerda
$ #PlacementBottomLeft
# Em Baixo a Esquerda
$ #PlacementTopCenter
# No Alto ao Centro
$ #PlacementBottomCenter
# Em Baixo ao Centro
$ #PlacementTopRight
# No Alto a Direita
$ #PlacementCenterRight
# No Meio a Direita
$ #PlacementBottomRight
# Em Baixo a Direita

$ #AutoHide
# Auto-ocultar
