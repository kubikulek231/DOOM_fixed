$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: um erro occorreu enquanto consultava o servidor X.\n  \
existe outro window menager rodando no display. %s.\n
$ #ManagingScreen
# BScreen::BScreen: managing screen %d using visual 0x%lx, depth %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): impossivel carregar fonte '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): impossivel carregar fonte padr�o.\n
$ #EmptyMenuFile
# %s: arquivo de menu vazio\n
$ #xterm
# xterm
$ #Restart
# Reiniciar
$ #Exit
# Sair
$ #EXECError
# BScreen::parseMenuFile: [exec] erro, sem r�tulo de menu e/ou comando definido\n
$ #EXITError
# BScreen::parseMenuFile: [exit] erro, sem r�tulo de menu definido\n
$ #STYLEError
# BScreen::parseMenuFile: [style] erro, sem r�tulo de menu e/ou nome do arquivo \
definido\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] erro, sem r�tulo de menu definido\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] erro, nome de arquivo n�o definido\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] error, '%s' n�o � um arquivo regular\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] erro, sem r�tulo de menu definido\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] erro, sem r�tulo de menu definido\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] erro, sem r�tulo de menu definido\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] erro, sem diretorio difinido\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] erro, '%s' n�o � um \
diretorio\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] erro, '%s' n�o existe\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] erro, sem r�tulo de menu definido\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

