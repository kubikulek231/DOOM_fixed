$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: creare 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: XGetWindowAttributres a esuat\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: nu gasesc un ecran pentru fereastra de baza 0x%lx\n
$ #Unnamed
# Fara nume
$ #MapRequest
# BlackboxWindow::mapRequestEvent() pentru 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() pentru 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: reasociere 0x%lx la 0x%lx\n
