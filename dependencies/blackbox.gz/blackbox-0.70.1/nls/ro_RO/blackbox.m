$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: nu este disponibil nici un ecran, rularea se intrerupe\n
$ #MapRequest
# Blackbox::process_event: MapRequest pentru 0x%lx\n
