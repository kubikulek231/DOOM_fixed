$set 10 #Windowmenu

$ #SendTo
# Trimite in ...
$ #Shade
# Micsorare
$ #Iconify
# Ascundere
$ #Maximize
# Marire maxima
$ #Raise
# Ridicare
$ #Lower
# Coborare
$ #Stick
# Persistenta
$ #KillClient
# Terminare fortata
$ #Close
# Inchidere
