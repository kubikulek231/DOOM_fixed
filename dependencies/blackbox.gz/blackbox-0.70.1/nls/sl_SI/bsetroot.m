$set 16 #bsetroot

$ #MustSpecify
# %s: napaka: dolo�iti je treba eno: -solid, -mod, -gradient\n
$ #Usage
# %s 2.0: (c) 1997-2000 Brad Hughes\n\n\
	  (c) 2001-2002 Sean 'Shaleh' Perry\n\n\
  -display <string>        prika�i povezavo\n\
  -mod <x> <y>             vzorec\n\
  -foreground, -fg <color> barva ospredja\n\
  -background, -bg <color> barva ozadja\n\n\
  -gradient <texture>      prelivna tekstura\n\
  -from <color>            za�etna barva preliva\n\
  -to <color>              kon�na barva preliva\n\n\
  -solid <color>           enotna barva\n\n\
  -help                    prika�i ta navodila in kon�aj\n

