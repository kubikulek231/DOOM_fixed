$set 14 #main

$ #RCRequiresArg
# napaka: '-rc' zahteva argument\n
$ #DISPLAYRequiresArg
# napaka: '-display' zahteva argument\n
$ #WarnDisplaySet
# opozorilo: spremenljivke okolja 'DISPLAY' ni mo� nastaviti\n
$ #Usage
# Blackbox %s: (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <string>\t\tuporabi prikazovalnik.\n\
  -rc <string>\t\t\tuporabi nadomestno datoteko z viri.\n\
  -version\t\t\tprika�i oznako razli�ice in kon�aj.\n\
  -help\t\t\t\prika�i ta navodila in kon�aj.\n\n
$ #CompileOptions
# Izbire pri prevajanju:\n\
  Razhro��evanje\t\t\t%s\n\
  Oblika:\t\t\t%s\n\
  Osembitno stresanje barv:\t%s\n\n
