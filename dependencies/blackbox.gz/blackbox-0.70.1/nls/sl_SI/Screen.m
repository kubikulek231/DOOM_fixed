$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: napaka pri poizvedovanju stre�nika za X.\n  \
nek upravljalnik oken �e te�e v prikazovalniku %s.\n
$ #ManagingScreen
# BScreen::BScreen: upravljenje zaslona %d z videzem 0x%lx globine %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): pisave '%s' ni mo� nalo�iti\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): privzete pisave ni mo� nalo�iti.\n
$ #EmptyMenuFile
# %s: prazna menujska datoteka\n
$ #xterm
# xterm
$ #Restart
# Ponovni zagon
$ #Exit
# Izhod
$ #EXECError
# BScreen::parseMenuFile: [exec] napaka: oznaki menuja ali ukaza nista dolo�eni\n
$ #EXITError
# BScreen::parseMenuFile: [exit] napaka: oznaka menuja ni dolo�ena\n
$ #STYLEError
# BScreen::parseMenuFile: [style] napaka: oznaki menuja ali datoteke nista dolo�eni\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] napaka: oznaka menuja ni dolo�ena\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] napaka: ime datoteke ni dolo�eno\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] napaka: '%s' ni prava datoteka\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] napaka: oznaka menuja ni dolo�ena\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] napaka: oznaka menuja ni dolo�ena\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] napaka: oznaka menuja ni dolo�ena\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] napaka: imenik ni dolo�en\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] napaka: '%s' ni imenik\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] napaka:, '%s' ne obstaja\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] napaka: oznaka menuja ni dolo�ena\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

