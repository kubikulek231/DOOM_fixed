$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow : 0x%lx'i yarat#_yorum\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow : XGetWindowAttributres ba�ar�s�z oldu\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow : 0x%lx ana penceresi i�in ekran� belirleyemedim\n
$ #Unnamed
# Isimsiz
$ #MapRequest
# 0x%lx i�in BlackboxWindow::mapRequestEvent()\n
$ #UnmapNotify
# 0x%lx i�in BlackboxWindow::unmapNotifyEvent()\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: 0x%lx'i ana pencereyi boya 0x%lx\n
