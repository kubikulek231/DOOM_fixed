$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid : resmi yaratamad�m\n
$ #ErrorCreatingXImage
# BImage::renderXImage : XImage'i yaratamad�m\n
$ #UnsupVisual
# BImage::renderXImage : desteklenmeyen g�r�n��( renk derinli�i )\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap : resmi yaratamad�m\n
$ #InvalidColormapSize
# BImageControl::BImageControl : ge�ersiz renk haritas� b�y�kl��� %d (%d/%d/%d) - azalt�yorum\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl : renk haritas� ayr�lanamad�\n
$ #ColorAllocFail
# BImageControl::BImageControl : rengi ayr�rken hata oldu : %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl : resim arabelle�i - %d resim temizlendi\n
$ #PixmapCacheLarge
# BImageControl::renderImage : arabellek b�y�k, temizlemeye ba�l�yorum\n
$ #ColorParseError
# BImageControl::getColor : renk tarama hatas� : '%s'\n
$ #ColorAllocError
# BImageControl::getColor : renk ay�rma hatas� : '%s'\n
