$set 14 #main

$ #RCRequiresArg
# hata : '-rc' bir arg�man bekler\n
$ #DISPLAYRequiresArg
# hata : '-display' bir arg�man bekler\n
$ #WarnDisplaySet
# ikaz : 'DISPLAY' verisini oturtamad�m\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <metin>\t\tekran� kullan.\n\
  -rc <metin>\t\t\tba�ka bir ayarlama dosyas�n� kullan.\n\
  -version\t\t\tnesil bilgisini g�sterir ve ��kar.\n\
  -help\t\t\t\tbu yard�m iletisini g�sterir ve ��kar.\n\n
$ #CompileOptions
# Denetleme se�enekleri :\n\
  Bilgilendirme\t\t\t%s\n\
  G�lgeleme:\t\t\t%s\n\
  R8b'e g�re t�zla:\t%s\n\n
