$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: y�netebilinen ekran bulunamad�, bitiriliyorum\n
$ #MapRequest
# Blackbox::process_event: 0x%lx i�in MapRequest\n
