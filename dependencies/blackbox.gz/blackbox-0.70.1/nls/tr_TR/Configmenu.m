$set 3 #Configmenu

$ #ConfigOptions
# Ayarlar
$ #FocusModel
# Fok�sleme
$ #WindowPlacement
# Pencere yerle�imi
$ #ImageDithering
# Resim olu�turmas�
$ #OpaqueMove
# Ekran� i�erikli ta��
$ #FullMax
# Tam ekranla, vallahi
$ #FocusNew
# Yeni pencereleri fok�sle
$ #FocusLast
# Masa�st�ndeki son pencereyi fok�sle
$ #ClickToFocus
# T�klayarak fok�sle
$ #SloppyFocus
# A��r fok�sle
$ #AutoRaise
# Otomatikman y�kselt
$ #SmartRows
# Ak�ll� yerle�im( S�ralar )
$ #SmartCols
# Ak�ll� yerle�im( S�tunlar )
$ #Cascade
# Cascade Placement
$ #LeftRight
# Soldan sa�a
$ #RightLeft
# Sa�dan sola
$ #TopBottom
# �stten a�a�a
$ #BottomTop
# Alttan �ste
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
