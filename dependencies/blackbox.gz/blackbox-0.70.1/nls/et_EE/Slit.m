$set 7 #Slit

$ #SlitTitle
# Pragu
$ #SlitDirection
# Prao suund
$ #SlitPlacement
# Prao asukoht
