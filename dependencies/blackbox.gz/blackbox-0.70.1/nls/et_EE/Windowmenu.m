$set 10 #Windowmenu

$ #SendTo
# Saada...
$ #Shade
# Varjuta
$ #Iconify
# Ikoniseeri
$ #Maximize
# Suurenda
$ #Raise
# Esiplaanile
$ #Lower
# Tahaplaanile
$ #Stick
# Kleebi
$ #KillClient
# Killi klient
$ #Close
# Sulge
