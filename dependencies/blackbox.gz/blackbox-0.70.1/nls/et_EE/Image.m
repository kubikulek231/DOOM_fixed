$set 5 #Image

$ #ErrorCreatingSolidPixmap
# BImage::render_solid: viga pixmapi loomisel\n
$ #ErrorCreatingXImage
# BImage::renderXImage: viga XImage loomisel\n
$ #UnsupVisual
# BImage::renderXImage: toeta visuaal\n
$ #ErrorCreatingPixmap
# BImage::renderPixmap: viga pixmapi loomisel\n
$ #InvalidColormapSize
# BImageControl::BImageControl: vale v�rvipaletti suurus %d (%d/%d/%d) - v�hendame\n
$ #ErrorAllocatingColormap
# BImageControl::BImageControl: viga v�rvipaletti m��ramisel \n
$ #ColorAllocFail
# BImageControl::BImageControl: ei �nnestunud v�rvi m��rata %d/%d/%d\n
$ #PixmapRelease
# BImageControl::~BImageControl: pixmap cache - vabastame %d pixmappi\n
$ #PixmapCacheLarge
# BImageControl::renderImage: cache on liiga suur, sundpuhastus\n
$ #ColorParseError
# BImageControl::getColor: viga v�rvi anal��simisel: '%s'\n
$ #ColorAllocError
# BImageControl::getColor: viga v�rvi m��ramisel: '%s'\n
