$set 6 #Screen

$ #AnotherWMRunning
# BScreen::BScreen: viga X serveri k�sitlemisel.\n  \
teine akahaldur juba t��tab displeil %s.\n
$ #ManagingScreen
# BScreen::BScreen: haldame displeid %d reolutsioonis 0x%lx, v�rvis�gavusel %d\n
$ #FontLoadFail
# BScreen::LoadStyle(): ei saanud laadida fonti '%s'\n
$ #DefaultFontLoadFail
# BScreen::LoadStyle(): ei saanud laadida vaikimisi m��ratud fonti.\n
$ #EmptyMenuFile
# %s: t�hi men��fail\n
$ #xterm
# xterm
$ #Restart
# Restart
$ #Exit
# V�lju
$ #EXECError
# BScreen::parseMenuFile: [exec] viga, men�� pealkirja ja/v�i k�sku pole m��ratud\n
$ #EXITError
# BScreen::parseMenuFile: [exit] viga, men�� pealkirja pole m��ratud\n
$ #STYLEError
# BScreen::parseMenuFile: [style] viga, men�� pealkirja ja/v�i failinime \
pole m��ratud\n
$ #CONFIGError
# BScreen::parseMenuFile: [config] viga, men�� pealkirja pole m��ratud\n
$ #INCLUDEError
# BScreen::parseMenuFile: [include] viga, failinime pole m��ratud\n
$ #INCLUDEErrorReg
# BScreen::parseMenuFile: [include] viga, '%s' ei ole tavaline fail\n
$ #SUBMENUError
# BScreen::parseMenuFile: [submenu] viga, men�� pealkirja pole m��ratud\n
$ #RESTARTError
# BScreen::parseMenuFile: [restart] viga, men�� pealkirja pole m��ratud\n
$ #RECONFIGError
# BScreen::parseMenuFile: [reconfig] viga, men�� pealkirja pole m��ratud\n
$ #STYLESDIRError
# BScreen::parseMenuFile: [stylesdir/stylesmenu] viga, kataloogi pole m��ratud\n
$ #STYLESDIRErrorNotDir
# BScreen::parseMenuFile: [stylesdir/stylesmenu] viga, '%s' pole kataloog\n
$ #STYLESDIRErrorNoExist
# BScreen::parseMenuFile: [stylesdir/stylesmenu] viga, '%s' pole olemas\n
$ #WORKSPACESError
# BScreen::parseMenuFile: [workspaces] viga, men�� pealkirja pole m��ratud\n
$ #PositionLength
# 0: 0000 x 0: 0000
$ #PositionFormat
# X: %4d x Y: %4d
$ #GeometryFormat
# W: %4d x H: %4d

