$set 14 #main

$ #RCRequiresArg
# Erreur: '-rc' n�cessite un argument\n
$ #DISPLAYRequiresArg
# Erreur: '-display' n�cessite un argument\n
$ #WarnDisplaySet
# Attention: impossible d'attribuer la variable d'environnement 'DISPLAY'\n
$ #Usage
# Blackbox %s : (c) 2001 - 2002 Sean 'Shaleh' Perry\n\
  \t\t\t 1997 - 2000, 2002 Brad Hughes\n\n\
  -display <cha�ne>\t\tutilise la connexion � l'affichage.\n\
  -rc <cha�ne>\t\t\tutilise un autre fichier de configuration.\n\
  -version\t\t\taffiche la version et quitte.\n\
  -help\t\t\t\taffiche ce texte d'aide et quitte.\n\n
$ #CompileOptions
# Options de compilation:\n\
  Debugage\t\t\t%s\n\
  Shape:\t\t\t%s\n\
  8bpp Lissage ordonn�:\t%s\n\n
