$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: G�n�ration 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: Echec de XGetWindowAttributres\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: Impossible de trouver l'�cran de la fen�tre racine 0x%lx\n
$ #Unnamed
# Inconnu
$ #MapRequest
# BlackboxWindow::mapRequestEvent() pour 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() pour 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: r�attribue 0x%lx � la 0x%lx\n
