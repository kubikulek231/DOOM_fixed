$set 13 #blackbox

$ #NoManagableScreens
# Blackbox::Blackbox: Aucun �cran exploitable n'a �t� trouv�, annulation\n
$ #MapRequest
# Blackbox::process_event: MapRequest pour 0x%lx\n
