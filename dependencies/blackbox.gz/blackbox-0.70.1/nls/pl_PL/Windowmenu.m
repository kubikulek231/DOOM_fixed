$set 10 #Windowmenu

$ #SendTo
# Wy�lij na ...
$ #Shade
# Zwi�
$ #Iconify
# Ikonizuj
$ #Maximize
# Maksymalizuj
$ #Raise
# Na wierzch 
$ #Lower
# Pod sp�d
$ #Stick
# Przyklej
$ #KillClient
# Zabij
$ #Close
# Zamknij
