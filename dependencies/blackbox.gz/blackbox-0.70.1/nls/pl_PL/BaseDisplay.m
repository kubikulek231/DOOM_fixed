$set 1 #BaseDisplay

$ #XError
# %s:  b��d X: %s(%d) opcodes %d/%d\n  resource 0x%lx\n
$ #SignalCaught
# %s: z�apano sygna� %d\n
$ #ShuttingDown
# zamykam\n
$ #Aborting
# przerywam... zrzucam core\n
$ #XConnectFail
# BaseDisplay::BaseDisplay: Nie mo�na po��czy� si� z X serwerem.\n
$ #CloseOnExecFail
# BaseDisplay::BaseDisplay: Nie mo�na ustawi� po��czenia jako 'close-on-exec'\n
$ #BadWindowRemove
# BaseDisplay::eventLoop(): Usuwam z�e okno z kolejki zdarze�\n
