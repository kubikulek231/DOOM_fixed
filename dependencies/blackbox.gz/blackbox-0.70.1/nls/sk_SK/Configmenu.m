$set 3 #Configmenu

$ #ConfigOptions
# Konfigura�n� vo�by
$ #FocusModel
# Model zamerania
$ #WindowPlacement
# Umiestnenie okna
$ #ImageDithering
# Modifik�cia farieb a jasu na obraze
$ #OpaqueMove
# Pres�vanie cel�ho okna
$ #FullMax
# Pln� maximaliz�cia
$ #FocusNew
# Zamera� nov� okn�
$ #FocusLast
# Zamera� okno pri zmene pracovnej plochy
$ #DisableBindings
# Zak�za� v�zby s kl�vesou Scroll Lock
$ #ClickToFocus
# Klikn�� pre zameranie
$ #SloppyFocus
# Nedbanliv� zameranie
$ #AutoRaise
# Automaticky presun�� do popredia
$ #ClickRaise
# Po kliknut� presun�� do popredia
$ #SmartRows
# Inteligentn� umiestnenie (riadky)
$ #SmartCols
# Inteligentn� umiestnenie (st�pce)
$ #Cascade
# Kask�dov� umiestnenie
$ #LeftRight
# Z�ava doprava
$ #RightLeft
# Sprava do�ava
$ #TopBottom
# Zhora nadol
$ #BottomTop
# Zdola nahor
$ #NoDithering
# Do not dither images
$ #OrderedDithering
# Use fast dither
$ #FloydSteinbergDithering
# Use high-quality dither
