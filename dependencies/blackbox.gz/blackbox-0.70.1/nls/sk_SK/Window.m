$set 9 #Window


$ #Creating
# BlackboxWindow::BlackboxWindow: vytv�ra sa 0x%lx\n
$ #XGetWindowAttributesFail
# BlackboxWindow::BlackboxWindow: zlyhanie XGetWindowAttributres\n
$ #CannotFindScreen
# BlackboxWindow::BlackboxWindow: nie je mo�n� n�js� obrazovku pre z�kladn� okno 0x%lx\n
$ #Unnamed
# Nepomenovan�
$ #MapRequest
# BlackboxWindow::mapRequestEvent() pre 0x%lx\n
$ #UnmapNotify
# BlackboxWindow::unmapNotifyEvent() pre 0x%lx\n
$ #ReparentNotify
# BlackboxWindow::reparentNotifyEvent: zmena potomka 0x%lx na rodi�a 0x%lx\n
